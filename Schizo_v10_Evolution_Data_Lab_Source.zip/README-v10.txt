Schizo v10 — Evolution & Data Lab

Portable source snapshot from the current Hatchable project.

Live app: https://qemvnn.hatchable.site

Includes the v1-v7 evolution documentation, v10 UI structure, CSV Data Lab endpoint, and Hatchable configuration. This is a portable source snapshot, not an official Hatchable export archive.

The app is an organization/data workspace, not a diagnostic system. CSV analysis is descriptive only.
