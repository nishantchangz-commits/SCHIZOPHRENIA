
# Schizo Model Training Pipeline v1

This package was created from the two notebooks you supplied.

## What the notebooks contain

### EEG CNN notebook
It uses the Kaggle `button-tone-sz` / `buttontonesz2` EEG data, averages every 16 rows,
normalizes the signal, reshapes it as electrode × time × channel, and trains a CNN with:
Conv2D → MaxPooling → Conv2D → MaxPooling → Dropout → Flatten → Dense → sigmoid.

### Symptoms notebook
It loads `SchizophreniaSymptomnsData.csv`, uses `Schizophrenia` as the target,
removes `Name`, imputes/scales numeric fields, one-hot encodes categorical fields,
and compares Random Forest, Logistic Regression, SVM, Gradient Boosting,
Decision Tree, plus other ensemble/XGBoost/SHAP analyses in the original notebook.

## Why there is no trained model in this ZIP

The uploaded `.ipynb` files contain notebook code and dataset paths, but the actual
EEG CSV dataset folders and the symptom CSV are not contained in the uploads.
Training without those records would mean inventing data/results.

## Run symptoms model

    pip install numpy pandas scikit-learn joblib
    python train_schizo_models.py --mode symptoms --input SchizophreniaSymptomnsData.csv --out models

## Run EEG CNN

    pip install numpy pandas scikit-learn tensorflow joblib
    python train_schizo_models.py --mode eeg --input /path/to/dataset_root --out models --epochs 50

The EEG dataset root should contain `button-tone-sz` and optionally `buttontonesz2`.

## Important methodological improvement

The supplied EEG notebook splits individual trials randomly. This can put trials from
the same person into both training and test sets. The supplied training script instead
uses a subject-level split, which is more appropriate for estimating generalization
to unseen people.

These models are for research/education and must not be used as a standalone
schizophrenia diagnosis.
