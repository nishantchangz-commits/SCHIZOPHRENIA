
"""
Schizo Model Training Pipeline v1
Based on the two supplied notebooks:
1) EEG CNN: button-tone-sz / buttontonesz2
2) Symptom analysis: SchizophreniaSymptomnsData.csv

IMPORTANT:
- This trains research/educational classifiers; it is NOT a diagnostic tool.
- The uploaded notebooks contain code and references to datasets, but the actual EEG CSV
  folders and symptom CSV were not included in the uploads, so this script cannot
  honestly produce a trained model until those datasets are supplied.
"""

import argparse, os, json, glob, warnings
import numpy as np
import pandas as pd
warnings.filterwarnings("ignore")

def train_symptoms(csv_path, out_dir):
    from sklearn.model_selection import train_test_split
    from sklearn.preprocessing import OneHotEncoder, StandardScaler, LabelEncoder
    from sklearn.compose import ColumnTransformer
    from sklearn.pipeline import Pipeline
    from sklearn.impute import SimpleImputer
    from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, roc_auc_score
    from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
    from sklearn.linear_model import LogisticRegression
    from sklearn.svm import SVC
    from sklearn.tree import DecisionTreeClassifier
    import joblib

    data = pd.read_csv(csv_path)
    if "Schizophrenia" not in data.columns:
        raise ValueError("Expected target column 'Schizophrenia' was not found.")

    drop_cols = [c for c in ["Schizophrenia", "Name"] if c in data.columns]
    X = data.drop(columns=drop_cols)
    y = data["Schizophrenia"]

    categorical = X.select_dtypes(include=["object", "category"]).columns.tolist()
    numerical = X.select_dtypes(include=[np.number]).columns.tolist()

    pre = ColumnTransformer([
        ("num", Pipeline([
            ("imputer", SimpleImputer(strategy="mean")),
            ("scaler", StandardScaler())
        ]), numerical),
        ("cat", Pipeline([
            ("imputer", SimpleImputer(strategy="most_frequent")),
            ("encoder", OneHotEncoder(handle_unknown="ignore"))
        ]), categorical)
    ])

    le = LabelEncoder()
    y_enc = le.fit_transform(y)

    X_train, X_test, y_train, y_test = train_test_split(
        X, y_enc, test_size=0.2, random_state=42, stratify=y_enc
    )

    models = {
        "RandomForest": RandomForestClassifier(random_state=42, n_estimators=300),
        "LogisticRegression": LogisticRegression(max_iter=2000, random_state=42),
        "SVM": SVC(probability=True, random_state=42),
        "GradientBoosting": GradientBoostingClassifier(random_state=42),
        "DecisionTree": DecisionTreeClassifier(random_state=42),
    }

    os.makedirs(out_dir, exist_ok=True)
    results = {}

    for name, clf in models.items():
        pipe = Pipeline([("preprocessor", pre), ("classifier", clf)])
        pipe.fit(X_train, y_train)
        pred = pipe.predict(X_test)
        acc = accuracy_score(y_test, pred)
        results[name] = {
            "accuracy": float(acc),
            "confusion_matrix": confusion_matrix(y_test, pred).tolist(),
            "classification_report": classification_report(
                y_test, pred, target_names=[str(x) for x in le.classes_], output_dict=True
            )
        }
        joblib.dump({"pipeline": pipe, "label_encoder": le},
                    os.path.join(out_dir, f"{name}.joblib"))

    with open(os.path.join(out_dir, "symptom_results.json"), "w") as f:
        json.dump(results, f, indent=2)

    print("Symptom models trained.")
    for k, v in results.items():
        print(f"{k}: {v['accuracy']:.4f}")

def averaged_by_n_rows(a, n):
    if a.shape[0] % n:
        raise ValueError(f"Trial has {a.shape[0]} rows; expected a multiple of {n}.")
    return a.reshape(a.shape[0] // n, n, a.shape[1]).mean(axis=1)

def train_eeg(dataset_root, out_dir, epochs=50):
    """
    Expected dataset layout:
      dataset_root/button-tone-sz/demographic.csv
      dataset_root/button-tone-sz/columnLabels.csv
      dataset_root/button-tone-sz/1.csv/1.csv ... 81.csv/81.csv
      dataset_root/buttontonesz2/... (fallback for missing subjects)

    This follows the uploaded EEG notebook's core preprocessing/model architecture,
    but uses a subject-level split to reduce leakage between trials from the same person.
    """
    import tensorflow as tf
    from sklearn.model_selection import GroupShuffleSplit
    from sklearn.preprocessing import normalize
    from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
    import joblib

    p1 = os.path.join(dataset_root, "button-tone-sz")
    p2 = os.path.join(dataset_root, "buttontonesz2")
    demographic = pd.read_csv(os.path.join(p1, "demographic.csv"))
    labels = dict(zip(demographic["subject"], demographic[" group"]))
    columns = pd.read_csv(os.path.join(p1, "columnLabels.csv")).columns.tolist()
    electrodes = columns[4:]
    N_AVERAGED = 16

    X, y, groups = [], [], []
    for subject in range(1, 82):
        path = os.path.join(p1, f"{subject}.csv", f"{subject}.csv")
        if not os.path.exists(path):
            path = os.path.join(p2, f"{subject}.csv", f"{subject}.csv")
        if not os.path.exists(path):
            continue
        df = pd.read_csv(path, header=None, names=columns)
        for trial in pd.unique(df["trial"]):
            trial_df = df[df["trial"] == trial]
            if len(trial_df) != 9216:
                continue
            arr = trial_df[electrodes].values.astype("float32")
            arr = averaged_by_n_rows(arr, N_AVERAGED).reshape(-1)
            X.append(arr); y.append(labels[subject]); groups.append(subject)

    if not X:
        raise ValueError("No valid EEG trials found. Check the dataset layout.")

    X = np.asarray(X, dtype="float32")
    y = np.asarray(y, dtype="float32")
    groups = np.asarray(groups)

    # Column-wise max normalization, matching the supplied notebook's intent.
    X_norm = normalize(X.reshape(-1, 70), axis=0, norm="max").reshape(X.shape)
    X2d = X_norm.reshape(len(X_norm), len(electrodes), X_norm.shape[1] // len(electrodes), 1)

    gss = GroupShuffleSplit(n_splits=1, test_size=0.2, random_state=42)
    tr, te = next(gss.split(X2d, y, groups=groups))

    model = tf.keras.Sequential([
        tf.keras.layers.Input(shape=X2d.shape[1:]),
        tf.keras.layers.Conv2D(32, kernel_size=(5,20), activation="tanh"),
        tf.keras.layers.MaxPooling2D(pool_size=(5,15)),
        tf.keras.layers.Conv2D(13, kernel_size=(3,3), activation="tanh"),
        tf.keras.layers.MaxPooling2D(pool_size=(3,3)),
        tf.keras.layers.Dropout(0.2),
        tf.keras.layers.Flatten(),
        tf.keras.layers.Dense(317, activation="relu"),
        tf.keras.layers.Dense(1, activation="sigmoid")
    ])
    model.compile(
        loss="binary_crossentropy",
        optimizer=tf.keras.optimizers.Adam(learning_rate=7.5e-6),
        metrics=["accuracy"]
    )

    os.makedirs(out_dir, exist_ok=True)
    callbacks = [
        tf.keras.callbacks.ModelCheckpoint(
            os.path.join(out_dir, "eeg_cnn_best.keras"),
            monitor="val_accuracy", save_best_only=True, mode="max"
        ),
        tf.keras.callbacks.EarlyStopping(
            monitor="val_loss", patience=12, restore_best_weights=True
        )
    ]

    hist = model.fit(
        X2d[tr], y[tr], batch_size=256, epochs=epochs, shuffle=True,
        validation_data=(X2d[te], y[te]), callbacks=callbacks, verbose=1
    )

    prob = model.predict(X2d[te], verbose=0).ravel()
    pred = (prob >= 0.5).astype(int)
    results = {
        "subjects_total": int(len(np.unique(groups))),
        "trials_total": int(len(X)),
        "test_subjects": int(len(np.unique(groups[te]))),
        "accuracy": float(accuracy_score(y[te], pred)),
        "confusion_matrix": confusion_matrix(y[te], pred).tolist(),
        "classification_report": classification_report(y[te], pred, output_dict=True),
        "note": "Research/educational result; not a clinical diagnostic performance estimate."
    }
    with open(os.path.join(out_dir, "eeg_results.json"), "w") as f:
        json.dump(results, f, indent=2)
    model.save(os.path.join(out_dir, "eeg_cnn_final.keras"))
    print(json.dumps(results, indent=2))

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--mode", choices=["symptoms", "eeg"], required=True)
    ap.add_argument("--input", required=True, help="CSV path for symptoms OR dataset root for EEG")
    ap.add_argument("--out", default="models")
    ap.add_argument("--epochs", type=int, default=50)
    args = ap.parse_args()
    if args.mode == "symptoms":
        train_symptoms(args.input, args.out)
    else:
        train_eeg(args.input, args.out, args.epochs)
