# Mind Timeline v3.0 Hatchable Source

This is a Hatchable-ready source package for the v3.0 research-first foundation.

Live project: https://mind-timeline-v30.hatchable.site
Console: https://hatchable.com/console/projects/mind-timeline-v30

Includes personal timeline, optional location, research catalog API, knowledge library, Postgres migrations, user-scoped routes, and the privacy boundary between personal records and research.

Research references planned/used by the deployed catalog include WHO Global Health Observatory, WHO World Health Statistics, WHO GHO API, WHO ICD-11, WHO schizophrenia/mental-health guidance, NIMH RDoC, NIMH Data Archive/AMP-SCZ, OpenNeuro and Kaggle. Check each source's access and license terms before downloading or redistributing data.

The app is not a diagnostic system. Public visibility is currently Personal in Hatchable Settings.
