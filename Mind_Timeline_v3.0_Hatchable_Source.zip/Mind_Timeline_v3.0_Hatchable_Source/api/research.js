import { db } from 'hatchable';
export const access='user';
export const methods=['GET'];
export default async function(req,res){const {rows}=await db.query('SELECT * FROM research_sources ORDER BY organization,title');res.json(rows)}
