import { db } from 'hatchable';
export const access='user';
export const methods=['GET','POST'];
export default async function(req,res){const u=req.user;if(req.method==='GET'){const {rows}=await db.query('SELECT * FROM knowledge_documents WHERE user_id=$1 ORDER BY created_at DESC',[u.id]);return res.json(rows)}const b=req.body||{};if(!b.title)return res.status(400).json({error:'title required'});const {rows}=await db.query('INSERT INTO knowledge_documents (user_id,title,source_url,source_type,topic,content) VALUES ($1,$2,$3,$4,$5,$6) RETURNING *',[u.id,b.title,b.source_url||null,b.source_type||'article',b.topic||null,b.content||null]);res.status(201).json(rows[0])}
