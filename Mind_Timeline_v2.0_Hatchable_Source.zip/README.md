# Mind Timeline v2.0 — Hatchable Source

Privacy-first journaling and communication application.

## Features
- End-user email authentication
- Multiple projects/timelines
- Events and relationships
- Timeline, dashboard and mind-map relationship views
- Analytics
- JSON and anonymous exports
- Audit history
- Privacy controls
- Optional AI organization helper

## Run/deploy
This source is designed for Hatchable. Import the project files into a Hatchable project and deploy.

The app is a journaling/communication tool, not a diagnostic system.
