CREATE TABLE IF NOT EXISTS history (
 id BIGSERIAL PRIMARY KEY,
 project_id BIGINT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
 user_id TEXT NOT NULL,
 action TEXT NOT NULL,
 entity_type TEXT NOT NULL,
 entity_id TEXT,
 snapshot JSONB,
 created_at TIMESTAMPTZ DEFAULT now()
);
