CREATE TABLE IF NOT EXISTS events (
 id BIGSERIAL PRIMARY KEY,
 project_id BIGINT NOT NULL REFERENCES projects(id) ON DELETE CASCADE,
 user_id TEXT NOT NULL,
 title TEXT NOT NULL,
 event_date DATE NOT NULL,
 category TEXT DEFAULT 'other',
 context TEXT DEFAULT '',
 significance TEXT DEFAULT '',
 confidence DOUBLE PRECISION DEFAULT 0.5,
 evidence_status TEXT DEFAULT 'unknown',
 tags TEXT DEFAULT '',
 notes TEXT DEFAULT '',
 created_at TIMESTAMPTZ DEFAULT now(),
 updated_at TIMESTAMPTZ DEFAULT now()
);
