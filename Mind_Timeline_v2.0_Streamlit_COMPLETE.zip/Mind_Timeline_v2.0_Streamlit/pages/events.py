
import streamlit as st
from datetime import date
from services.event_service import CATEGORIES,EVIDENCE
from utils.validation import validate_event
from services.ai_service import organize_text

def render(project_id,events,create_event,update_event,delete_event):
    st.header("📝 Events")
    mode=st.radio("Mode",["Create","Edit"],horizontal=True)
    if mode=="Create":
        with st.form("create_event"):
            title=st.text_input("Title *")
            d=st.date_input("Date",date.today())
            category=st.selectbox("Category",CATEGORIES)
            context=st.text_area("Context")
            significance=st.text_area("Significance")
            confidence=st.slider("Confidence",0.0,1.0,0.5,0.05)
            evidence=st.selectbox("Evidence status",EVIDENCE)
            tags=st.text_input("Tags")
            notes=st.text_area("Notes")
            submitted=st.form_submit_button("Save event")
        if submitted:
            errors=validate_event(title,confidence)
            if errors:
                for x in errors: st.error(x)
            else:
                create_event(project_id,{"title":title.strip(),"event_date":d.isoformat(),
                    "category":category,"context":context,"significance":significance,
                    "confidence":confidence,"evidence_status":evidence,"tags":tags,"notes":notes})
                st.success("Event created."); st.rerun()
    else:
        if not events:
            st.info("No events to edit.")
            return
        labels={f"{e['event_date']} — {e['title']}":e["id"] for e in events}
        selected=st.selectbox("Select event",list(labels))
        e=next(x for x in events if x["id"]==labels[selected])
        with st.form("edit_event"):
            title=st.text_input("Title",e["title"])
            d=st.date_input("Date",date.fromisoformat(e["event_date"]))
            category=st.selectbox("Category",CATEGORIES,index=CATEGORIES.index(e["category"]))
            context=st.text_area("Context",e["context"])
            significance=st.text_area("Significance",e["significance"])
            confidence=st.slider("Confidence",0.0,1.0,float(e["confidence"] or 0.5),0.05)
            evidence=st.selectbox("Evidence status",EVIDENCE,index=EVIDENCE.index(e["evidence_status"]))
            tags=st.text_input("Tags",e["tags"])
            notes=st.text_area("Notes",e["notes"])
            save=st.form_submit_button("Update event")
        if save:
            errs=validate_event(title,confidence)
            if errs:
                for x in errs: st.error(x)
            else:
                update_event(project_id,e["id"],{"title":title.strip(),"event_date":d.isoformat(),
                    "category":category,"context":context,"significance":significance,
                    "confidence":confidence,"evidence_status":evidence,"tags":tags,"notes":notes})
                st.success("Updated."); st.rerun()
        if st.button("Delete selected event",type="secondary"):
            delete_event(project_id,e["id"]); st.rerun()

    st.divider()
    st.subheader("Optional organization helper")
    raw=st.text_area("Paste text to organize (does not automatically save it)")
    if st.button("Organize text"):
        result=organize_text(raw)
        st.write("**Summary:**",result["summary"])
        st.write("**Possible keywords:**",", ".join(result["keywords"]) or "None")
