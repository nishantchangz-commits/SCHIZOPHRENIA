
import streamlit as st
import json
from database.db import get_conn, now, log
from services.event_service import create_event
from services.relationship_service import create_relationship

def render(project_id):
    st.header("📦 Backup / Restore")
    uploaded=st.file_uploader("Upload a Mind Timeline v2 JSON backup",type=["json"])
    if uploaded:
        try:
            payload=json.load(uploaded)
            st.json({"version":payload.get("version"),"event_count":len(payload.get("events",[])),
                     "relationship_count":len(payload.get("relationships",[]))})
            if st.button("Restore backup"):
                # Import as new IDs to avoid collisions; relationships are remapped.
                id_map={}
                for e in payload.get("events",[]):
                    data={k:e.get(k,"") for k in ["title","event_date","category","context","significance",
                                                  "confidence","evidence_status","tags","notes"]}
                    new_id=create_event(project_id,data)
                    id_map[e["id"]]=new_id
                for r in payload.get("relationships",[]):
                    if r.get("source_id") in id_map and r.get("target_id") in id_map:
                        create_relationship(project_id,id_map[r["source_id"]],id_map[r["target_id"]],
                                             r.get("relationship_type","related"),r.get("note",""))
                st.success("Backup restored as new records.")
                st.rerun()
        except Exception as ex:
            st.error(f"Invalid backup: {ex}")
