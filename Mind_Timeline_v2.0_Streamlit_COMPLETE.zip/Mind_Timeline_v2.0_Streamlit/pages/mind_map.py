
import streamlit as st
import plotly.graph_objects as go
import networkx as nx

def render(events, relationships):
    st.header("🕸️ Interactive Mind Map")
    if not events:
        st.info("Add events first.")
        return
    G=nx.Graph()
    for e in events: G.add_node(e["id"],label=e["title"],category=e["category"])
    for r in relationships:
        G.add_edge(r["source_id"],r["target_id"],rtype=r["relationship_type"])
    pos=nx.spring_layout(G,seed=42)
    edge_x=[]; edge_y=[]
    for a,b in G.edges():
        edge_x += [pos[a][0],pos[b][0],None]
        edge_y += [pos[a][1],pos[b][1],None]
    edge_trace=go.Scatter(x=edge_x,y=edge_y,mode="lines",
                          hoverinfo="none",line={"width":1})
    node_x=[pos[n][0] for n in G.nodes()]
    node_y=[pos[n][1] for n in G.nodes()]
    labels=[G.nodes[n]["label"] for n in G.nodes()]
    node_trace=go.Scatter(x=node_x,y=node_y,mode="markers+text",
                          text=labels,textposition="top center",
                          hovertext=[G.nodes[n]["category"] for n in G.nodes()],
                          hoverinfo="text",
                          marker={"size":18})
    fig=go.Figure([edge_trace,node_trace])
    fig.update_layout(height=650,showlegend=False,
                      xaxis={"visible":False},yaxis={"visible":False},
                      margin={"l":10,"r":10,"t":40,"b":10})
    st.plotly_chart(fig,use_container_width=True)
    st.caption("Drag nodes, zoom and pan. Relationship direction/type is shown in the table below.")
    if relationships: st.dataframe(relationships,use_container_width=True)
