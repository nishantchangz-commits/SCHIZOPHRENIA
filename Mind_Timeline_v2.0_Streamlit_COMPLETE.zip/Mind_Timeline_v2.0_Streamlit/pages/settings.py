
import streamlit as st
from services.project_service import update_project

def render(project):
    st.header("⚙️ Settings")
    with st.form("project_settings"):
        name=st.text_input("Project name",project["name"])
        desc=st.text_area("Description",project["description"])
        private=st.checkbox("Mark project private",bool(project["is_private"]))
        save=st.form_submit_button("Save settings")
    if save:
        update_project(project["id"],name,desc,private)
        st.success("Settings saved."); st.rerun()
