
import streamlit as st
import pandas as pd
import plotly.express as px

def render(events):
    st.header("📈 Analytics")
    if not events:
        st.info("No events yet."); return
    df=pd.DataFrame(events)
    a,b=st.columns(2)
    with a:
        st.plotly_chart(px.pie(df,names="category",title="Category distribution"),use_container_width=True)
    with b:
        st.plotly_chart(px.histogram(df,x="confidence",nbins=10,title="Confidence distribution"),use_container_width=True)
    st.subheader("Evidence status")
    st.bar_chart(df["evidence_status"].value_counts())
