
import streamlit as st
import json
from services.report_service import clinician_summary,full_export,anonymous_export
from utils.export import json_bytes,csv_bytes

def render(project,events,relationships,history):
    st.header("📋 Reports & Export")
    summary=clinician_summary(events,relationships)
    st.subheader("Neutral summary")
    st.text_area("Preview",summary,height=350)
    st.download_button("Download summary",summary,"mind_timeline_neutral_summary.txt","text/plain")

    full=full_export(project,events,relationships,history)
    st.download_button("Download full JSON",json_bytes(full),"mind_timeline_v2_backup.json","application/json")
    st.download_button("Download events CSV",csv_bytes(events),"mind_timeline_events.csv","text/csv")

    anon=anonymous_export(events,relationships)
    st.download_button("Download anonymous structured JSON",json_bytes(anon),
                       "mind_timeline_anonymous.json","application/json")
    st.info("Review exports carefully before sharing. Anonymous structured export removes free-text event fields.")
