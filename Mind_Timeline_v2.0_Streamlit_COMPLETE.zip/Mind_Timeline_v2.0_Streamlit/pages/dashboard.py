
import streamlit as st
import pandas as pd

def render(events, relationships):
    st.header("🏠 Dashboard")
    c1,c2,c3,c4=st.columns(4)
    c1.metric("Events",len(events))
    c2.metric("Relationships",len(relationships))
    c3.metric("Categories",len(set(e["category"] for e in events)) if events else 0)
    avg=sum(float(e["confidence"] or 0) for e in events)/len(events) if events else 0
    c4.metric("Avg. confidence",f"{avg:.2f}")
    if events:
        df=pd.DataFrame(events)
        st.subheader("Events by category")
        st.bar_chart(df["category"].value_counts())
        st.subheader("Recent events")
        st.dataframe(df[["event_date","title","category","confidence","evidence_status"]].head(10),
                     use_container_width=True)
