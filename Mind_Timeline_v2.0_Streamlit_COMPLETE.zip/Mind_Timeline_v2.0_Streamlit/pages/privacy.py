
import streamlit as st

def render(project):
    st.header("🔐 Privacy & Security")
    st.write("**Storage:** local SQLite database on this computer.")
    st.write("**Project privacy flag:**", "Private" if project["is_private"] else "Not marked private")
    st.warning("Local storage is not the same as cryptographic encryption. Protect the computer and database file.")
    st.write("Before sharing reports or exports, remove identifying/free-text information that is not necessary.")
