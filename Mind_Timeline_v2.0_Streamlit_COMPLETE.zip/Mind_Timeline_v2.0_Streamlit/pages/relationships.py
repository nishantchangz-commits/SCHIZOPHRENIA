
import streamlit as st
from services.relationship_service import TYPES

def render(project_id,events,relationships,create_relationship,delete_relationship):
    st.header("🔗 Relationships")
    if len(events)<2:
        st.info("Add at least two events.")
        return
    labels={f"{e['event_date']} — {e['title']}":e["id"] for e in events}
    a=st.selectbox("From",list(labels),key="rel_a")
    b=st.selectbox("To",[x for x in labels if x!=a],key="rel_b")
    typ=st.selectbox("Relationship type",TYPES)
    note=st.text_input("Note")
    if st.button("Create relationship"):
        try:
            create_relationship(project_id,labels[a],labels[b],typ,note)
            st.success("Relationship created."); st.rerun()
        except ValueError as ex: st.error(str(ex))
    st.subheader("Existing relationships")
    name={e["id"]:e["title"] for e in events}
    for r in relationships:
        st.write(f"**{name.get(r['source_id'],r['source_id'])}** → `{r['relationship_type']}` → **{name.get(r['target_id'],r['target_id'])}**")
        if st.button("Delete",key="dr_"+r["id"]):
            delete_relationship(project_id,r["id"]); st.rerun()
