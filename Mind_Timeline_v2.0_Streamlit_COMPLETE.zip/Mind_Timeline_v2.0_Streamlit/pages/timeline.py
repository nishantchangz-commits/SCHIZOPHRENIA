
import streamlit as st
import pandas as pd
import plotly.express as px

def render(events):
    st.header("📅 Timeline")
    if not events:
        st.info("No events yet.")
        return
    df=pd.DataFrame(events)
    df["event_date"]=pd.to_datetime(df["event_date"])
    fig=px.scatter(df,x="event_date",y="category",hover_name="title",
                   hover_data=["confidence","evidence_status"],title="Interactive Event Timeline")
    fig.update_layout(height=550)
    st.plotly_chart(fig,use_container_width=True)
