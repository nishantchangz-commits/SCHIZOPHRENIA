
from utils.validation import validate_event

def test_valid_event():
    assert validate_event("Test",0.5)==[]

def test_missing_title():
    assert "Title is required." in validate_event("",0.5)
