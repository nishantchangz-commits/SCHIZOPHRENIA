
import json
import pandas as pd

def json_bytes(obj):
    return json.dumps(obj,indent=2,ensure_ascii=False).encode("utf-8")

def csv_bytes(rows):
    return pd.DataFrame(rows).to_csv(index=False).encode("utf-8")
