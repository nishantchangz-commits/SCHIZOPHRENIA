
def validate_event(title, confidence):
    errors=[]
    if not title or not title.strip():
        errors.append("Title is required.")
    if not 0 <= float(confidence) <= 1:
        errors.append("Confidence must be between 0 and 1.")
    return errors
