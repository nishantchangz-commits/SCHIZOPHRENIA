
import json

def clinician_summary(events, relationships):
    lines=["Mind Timeline — Neutral Summary",
           "",
           "Structured communication record. This document is not a diagnosis.",
           ""]
    for e in sorted(events,key=lambda x:x["event_date"]):
        lines += [
            f"Date: {e['event_date']}",
            f"Category: {e['category']}",
            f"Title: {e['title']}",
            f"Context: {e['context']}",
            f"Significance: {e['significance']}",
            f"Evidence status: {e['evidence_status']}",
            f"Confidence: {e['confidence']}",
            f"Tags: {e['tags']}",
            f"Notes: {e['notes']}",
            "---"
        ]
    return "\n".join(lines)

def full_export(project,events,relationships,history):
    return {"version":"2.0","project":project,"events":events,
            "relationships":relationships,"history":history}

def anonymous_export(events,relationships):
    keys=["id","project_id","event_date","category","confidence","evidence_status","created_at","updated_at"]
    return {"version":"2.0-anonymous",
            "events":[{k:e.get(k) for k in keys} for e in events],
            "relationships":relationships}
