
import uuid
from database.db import get_conn, now, log

def list_projects():
    with get_conn() as c:
        return [dict(r) for r in c.execute("SELECT * FROM projects ORDER BY updated_at DESC")]

def create_project(name, description="", is_private=True):
    pid = str(uuid.uuid4()); t = now()
    with get_conn() as c:
        c.execute("INSERT INTO projects VALUES(?,?,?,?,?,?)",
                  (pid, name.strip(), description, int(is_private), t, t))
    log(pid, "create", "project", pid, {"name":name,"description":description,"is_private":is_private})
    return pid

def update_project(pid, name, description, is_private):
    with get_conn() as c:
        c.execute("UPDATE projects SET name=?,description=?,is_private=?,updated_at=? WHERE id=?",
                  (name,description,int(is_private),now(),pid))
    log(pid, "update", "project", pid, {"name":name,"description":description,"is_private":is_private})

def delete_project(pid):
    with get_conn() as c:
        c.execute("DELETE FROM projects WHERE id=?", (pid,))
