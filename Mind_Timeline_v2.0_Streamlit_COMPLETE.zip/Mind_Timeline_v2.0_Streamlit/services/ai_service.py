
def organize_text(text):
    """
    Safe local AI foundation. No model is called by default.
    Returns simple organization suggestions only.
    """
    text=text.strip()
    if not text:
        return {"summary":"","keywords":[],"suggestion":"Enter text first."}
    words=[w.strip(".,!?;:()[]{}").lower() for w in text.split()]
    keywords=list(dict.fromkeys([w for w in words if len(w)>4]))[:10]
    return {
        "summary": text[:500] + ("..." if len(text)>500 else ""),
        "keywords": keywords,
        "suggestion":"Review and approve any organization before saving."
    }
