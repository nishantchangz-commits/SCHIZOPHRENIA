
import uuid
from database.db import get_conn, now, log

TYPES=["related","before","after","supports","contrasts","context_for","caused_by","custom"]

def list_relationships(project_id):
    with get_conn() as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM relationships WHERE project_id=? ORDER BY created_at DESC",(project_id,))]

def create_relationship(project_id,source,target,rtype,note=""):
    if source==target: raise ValueError("An event cannot relate to itself.")
    rid=str(uuid.uuid4())
    with get_conn() as c:
        c.execute("INSERT INTO relationships VALUES(?,?,?,?,?,?,?)",
                  (rid,project_id,source,target,rtype,note,now()))
    log(project_id,"create","relationship",rid,
        {"id":rid,"source_id":source,"target_id":target,"relationship_type":rtype,"note":note})
    return rid

def delete_relationship(project_id,rid):
    with get_conn() as c:
        c.execute("DELETE FROM relationships WHERE id=? AND project_id=?",(rid,project_id))
