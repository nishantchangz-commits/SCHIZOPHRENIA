
def filter_events(events, query="", category="all", evidence="all", min_conf=0.0):
    q=query.strip().lower()
    result=[]
    for e in events:
        hay=" ".join(str(e.get(k,"")) for k in
                     ["title","context","significance","tags","notes","event_date","category"]).lower()
        if q and q not in hay: continue
        if category!="all" and e["category"]!=category: continue
        if evidence!="all" and e["evidence_status"]!=evidence: continue
        if float(e.get("confidence") or 0) < min_conf: continue
        result.append(e)
    return result
