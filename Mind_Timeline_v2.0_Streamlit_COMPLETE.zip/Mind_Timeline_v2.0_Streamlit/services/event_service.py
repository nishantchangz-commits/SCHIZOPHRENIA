
import uuid
from database.db import get_conn, now, log

CATEGORIES = ["observation","interpretation","imagination","dream","memory","perception","other"]
EVIDENCE = ["unknown","reported","supported","unverified","contradicted"]

def list_events(project_id):
    with get_conn() as c:
        return [dict(r) for r in c.execute(
            "SELECT * FROM events WHERE project_id=? ORDER BY event_date DESC, created_at DESC",(project_id,))]

def create_event(project_id, data):
    eid=str(uuid.uuid4()); t=now()
    row=(eid,project_id,data["title"],data["event_date"],data["category"],data["context"],
         data["significance"],data["confidence"],data["evidence_status"],data["tags"],data["notes"],t,t)
    with get_conn() as c:
        c.execute("INSERT INTO events VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",row)
    log(project_id,"create","event",eid,dict(zip(
        ["id","project_id","title","event_date","category","context","significance","confidence",
         "evidence_status","tags","notes","created_at","updated_at"],row)))
    return eid

def update_event(project_id,eid,data):
    with get_conn() as c:
        old=c.execute("SELECT * FROM events WHERE id=? AND project_id=?",(eid,project_id)).fetchone()
        if not old: return
        c.execute("""UPDATE events SET title=?,event_date=?,category=?,context=?,significance=?,
                     confidence=?,evidence_status=?,tags=?,notes=?,updated_at=? WHERE id=? AND project_id=?""",
                  (data["title"],data["event_date"],data["category"],data["context"],data["significance"],
                   data["confidence"],data["evidence_status"],data["tags"],data["notes"],now(),eid,project_id))
    log(project_id,"update","event",eid,dict(old))

def delete_event(project_id,eid):
    with get_conn() as c:
        old=c.execute("SELECT * FROM events WHERE id=? AND project_id=?",(eid,project_id)).fetchone()
        if old:
            c.execute("DELETE FROM events WHERE id=? AND project_id=?",(eid,project_id))
            log(project_id,"delete","event",eid,dict(old))

def get_event(project_id,eid):
    with get_conn() as c:
        r=c.execute("SELECT * FROM events WHERE id=? AND project_id=?",(eid,project_id)).fetchone()
        return dict(r) if r else None
