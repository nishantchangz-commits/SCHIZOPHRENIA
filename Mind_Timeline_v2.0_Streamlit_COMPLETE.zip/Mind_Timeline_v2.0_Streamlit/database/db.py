
import sqlite3
import uuid
import json
from pathlib import Path
from datetime import datetime, timezone

BASE = Path(__file__).resolve().parents[1]
DB_PATH = BASE / "data" / "mind_timeline_v2.db"
DB_PATH.parent.mkdir(exist_ok=True)

def now():
    return datetime.now(timezone.utc).isoformat()

def get_conn():
    c = sqlite3.connect(DB_PATH)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA foreign_keys=ON")
    return c

def init_db():
    with get_conn() as c:
        c.executescript("""
        CREATE TABLE IF NOT EXISTS projects(
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            description TEXT DEFAULT '',
            is_private INTEGER DEFAULT 1,
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS events(
            id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            title TEXT NOT NULL,
            event_date TEXT NOT NULL,
            category TEXT NOT NULL,
            context TEXT DEFAULT '',
            significance TEXT DEFAULT '',
            confidence REAL DEFAULT 0.5,
            evidence_status TEXT DEFAULT 'unknown',
            tags TEXT DEFAULT '',
            notes TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            updated_at TEXT NOT NULL,
            FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS relationships(
            id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            source_id TEXT NOT NULL,
            target_id TEXT NOT NULL,
            relationship_type TEXT NOT NULL,
            note TEXT DEFAULT '',
            created_at TEXT NOT NULL,
            FOREIGN KEY(project_id) REFERENCES projects(id) ON DELETE CASCADE,
            FOREIGN KEY(source_id) REFERENCES events(id) ON DELETE CASCADE,
            FOREIGN KEY(target_id) REFERENCES events(id) ON DELETE CASCADE
        );
        CREATE TABLE IF NOT EXISTS history(
            id TEXT PRIMARY KEY,
            project_id TEXT NOT NULL,
            action TEXT NOT NULL,
            entity_type TEXT NOT NULL,
            entity_id TEXT,
            snapshot TEXT DEFAULT '{}',
            created_at TEXT NOT NULL
        );
        """)

def seed():
    with get_conn() as c:
        if c.execute("SELECT COUNT(*) FROM projects").fetchone()[0] == 0:
            pid = str(uuid.uuid4())
            t = now()
            c.execute("INSERT INTO projects VALUES(?,?,?,?,?,?)",
                      (pid, "My Timeline", "Default Mind Timeline project", 1, t, t))

def log(project_id, action, entity_type, entity_id, snapshot):
    with get_conn() as c:
        c.execute("INSERT INTO history VALUES(?,?,?,?,?,?,?)",
                  (str(uuid.uuid4()), project_id, action, entity_type, entity_id,
                   json.dumps(snapshot, ensure_ascii=False), now()))
