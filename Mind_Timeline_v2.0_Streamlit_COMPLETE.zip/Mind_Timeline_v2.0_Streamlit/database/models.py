
from dataclasses import dataclass

@dataclass
class Project:
    id: str
    name: str
    description: str
    is_private: bool

@dataclass
class Event:
    id: str
    project_id: str
    title: str
    event_date: str
    category: str
    context: str
    significance: str
    confidence: float
    evidence_status: str
    tags: str
    notes: str

@dataclass
class Relationship:
    id: str
    project_id: str
    source_id: str
    target_id: str
    relationship_type: str
    note: str
