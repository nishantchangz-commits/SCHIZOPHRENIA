
from .db import init_db, seed

def migrate():
    init_db()
    seed()

if __name__ == "__main__":
    migrate()
