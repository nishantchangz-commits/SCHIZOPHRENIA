# Mind Timeline v2.0 — Streamlit

A standalone local journaling and communication application with:
- Multiple timelines/projects
- Rich event editor
- Advanced search/filtering
- Interactive timeline
- Interactive mind map
- Relationships and relationship types
- Dashboard and analytics
- Reports
- JSON/CSV export
- Full backup/restore
- Privacy controls
- Audit/version history
- Optional AI-organization foundation (disabled by default)

## Run on Windows

```bash
pip install -r requirements.txt
streamlit run app.py
```

The browser opens automatically. Data is stored locally in `data/mind_timeline_v2.db`.

## Important
This is a journaling/communication tool, not a diagnostic system.
AI features, when configured, should only organize or summarize user-provided information and should not be used to diagnose a person or confirm interpretations.
