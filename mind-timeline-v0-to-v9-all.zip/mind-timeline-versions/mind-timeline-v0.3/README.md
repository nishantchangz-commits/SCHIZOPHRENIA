# Mind Timeline v0.3

Interactive draggable mind map, explicit event relationships, search/filter, JSON import/export, neutral printable clinician view, mobile responsiveness, SVG connection lines, event editor.

## Purpose
This package is a standalone milestone for learning and development.

## Principle
Experience ≠ interpretation ≠ diagnosis.
This is a journaling/communication tool, not a diagnostic system.
