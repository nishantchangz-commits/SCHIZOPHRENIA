# Mind Timeline v0.7

Advanced graph and timeline visualization: relationship categories, clustering, nested timelines, zoom/pan, chronological and relationship views.

## Purpose
This package is a standalone milestone for learning and development.

## Principle
Experience ≠ interpretation ≠ diagnosis.
This is a journaling/communication tool, not a diagnostic system.
