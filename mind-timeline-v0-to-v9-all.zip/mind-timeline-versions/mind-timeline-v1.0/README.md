# Mind Timeline v1.0

Integrated local platform combining timeline, events, relationships, search/filter, history, neutral summary and structured anonymous export.

## Purpose
This package is a standalone milestone for learning and development.

## Principle
Experience ≠ interpretation ≠ diagnosis.
This is a journaling/communication tool, not a diagnostic system.
