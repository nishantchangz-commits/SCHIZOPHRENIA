from fastapi import FastAPI
from pydantic import BaseModel
from datetime import datetime, timezone

app = FastAPI(title="Mind Timeline v1.0")

class Event(BaseModel):
    title: str
    notes: str = ""
    category: str = "other"

events = []

@app.get("/health")
def health():
    return {"status": "ok", "version": "v1.0"}

@app.get("/events")
def list_events():
    return events

@app.post("/events")
def create_event(event: Event):
    item = event.model_dump()
    item["created_at"] = datetime.now(timezone.utc).isoformat()
    events.append(item)
    return item
