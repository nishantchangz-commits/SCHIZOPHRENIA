# Mind Timeline v0.5

Python/FastAPI foundation, SQLite-oriented architecture, CRUD APIs, relationships, validation, search/filter, JSON import/export, structured anonymous export, history.

## Purpose
This package is a standalone milestone for learning and development.

## Principle
Experience ≠ interpretation ≠ diagnosis.
This is a journaling/communication tool, not a diagnostic system.
