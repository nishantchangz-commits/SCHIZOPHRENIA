# Mind Timeline v0.6

Security-focused evolution: local protection, encrypted export/import design, stronger audit/version history and integrity checks.

## Purpose
This package is a standalone milestone for learning and development.

## Principle
Experience ≠ interpretation ≠ diagnosis.
This is a journaling/communication tool, not a diagnostic system.
