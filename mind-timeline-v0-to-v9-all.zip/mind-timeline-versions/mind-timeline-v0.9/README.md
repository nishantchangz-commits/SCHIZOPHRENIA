# Mind Timeline v0.9

Research-safe data workflow: de-identification, structured anonymous datasets, schema versioning, consent/status metadata and reproducible exports.

## Purpose
This package is a standalone milestone for learning and development.

## Principle
Experience ≠ interpretation ≠ diagnosis.
This is a journaling/communication tool, not a diagnostic system.
