# Mind Timeline v7.0

RAG-oriented architecture for retrieval over user-approved documents and records, with source attribution.

## Purpose
This package is a standalone milestone for learning and development.

## Principle
Experience ≠ interpretation ≠ diagnosis.
This is a journaling/communication tool, not a diagnostic system.
