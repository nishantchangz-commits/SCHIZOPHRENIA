# Mind Timeline v2.0

Multi-project workspace, richer graph navigation, modular APIs and improved import/export.

## Purpose
This package is a standalone milestone for learning and development.

## Principle
Experience ≠ interpretation ≠ diagnosis.
This is a journaling/communication tool, not a diagnostic system.
