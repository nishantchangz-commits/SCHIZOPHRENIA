# Mind Timeline v0.2

Timeline recording, search/filter, edit/delete, connections, nested timeline, clinician summary/print, JSON import/export, mobile support, local storage.

## Purpose
This package is a standalone milestone for learning and development.

## Principle
Experience ≠ interpretation ≠ diagnosis.
This is a journaling/communication tool, not a diagnostic system.
