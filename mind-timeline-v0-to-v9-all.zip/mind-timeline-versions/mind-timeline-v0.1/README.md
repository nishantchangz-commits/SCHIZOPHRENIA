# Mind Timeline v0.1

First browser version: local storage, event capture, labels, context, significance, confidence, links, nested timeline, JSON export.

## Purpose
This package is a standalone milestone for learning and development.

## Principle
Experience ≠ interpretation ≠ diagnosis.
This is a journaling/communication tool, not a diagnostic system.
