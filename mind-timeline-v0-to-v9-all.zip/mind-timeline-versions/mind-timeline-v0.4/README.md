# Mind Timeline v0.4

Public/private separation, relationship types, undo/redo foundation, interactive mind map, search/filter, JSON import/export, anonymous research export, neutral clinician summary, privacy-oriented GitHub structure.

## Purpose
This package is a standalone milestone for learning and development.

## Principle
Experience ≠ interpretation ≠ diagnosis.
This is a journaling/communication tool, not a diagnostic system.
