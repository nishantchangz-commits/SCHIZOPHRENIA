# Mind Timeline v5.0 Complete

Nature-inspired, privacy-first Mind Timeline organizer.

## Included
- Timeline Canvas with Early / Middle / Conclusive phases
- Events, edit/delete, search/filter
- Observation/experience vs interpretation
- Context, significance, confidence, evidence and tags
- Mind Map and explicit relationships
- Data / Records and JSON/TXT export
- Neutral Summary / print
- Separate 24-Hour Activity
- Movies & Music — personal log of films/albums that relate to schizophrenia, with your own rating and a note on how they portrayed it (not a source on the condition itself)
- Research Directory and Research Map
- Connect / Community section
- Request a Change
- All Tabs launcher
- Local-first browser storage

## Run locally
Open `public/index.html` in a browser.

## Hatchable
The original deployed project is hosted separately. This ZIP is a portable source snapshot of the v5 application.
