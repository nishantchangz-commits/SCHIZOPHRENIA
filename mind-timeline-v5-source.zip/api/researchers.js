export const access = "public";
export const methods = ["GET"];

export default async function(req,res){
  res.json({researchers:[
    {name:"Ganesan Venkatasubramanian",institution:"NIMHANS, Bengaluru",focus:"schizophrenia research, treatment and neuromodulation",public_email:"venkat.nimhans@gmail.com",paper:"https://pubmed.ncbi.nlm.nih.gov/40966902/"},
    {name:"Parmanand Kulhara",institution:"PGIMER, Chandigarh",focus:"schizophrenia research",public_email:"param_kulhara@yahoo.co.in"}
  ]});
}
