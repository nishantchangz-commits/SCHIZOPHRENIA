# Mind Timeline v1.0

A privacy-first journaling and communication application for organizing lived experiences.
It is **not a diagnostic, prediction, or treatment system**.

Core principle:
> Experience ≠ interpretation ≠ diagnosis

## Features
- FastAPI REST API
- SQLite local database
- Create/edit/delete events
- Observation, interpretation, imagination, dream, memory and perception labels
- Confidence and evidence-status fields
- Event-to-event relationships
- Nested timeline references
- Search and filtering
- Undo/redo-style audit history
- JSON import/export
- Anonymous structured research export
- Neutral clinician summary
- HTML mind-map view
- Basic security headers and API-key option
- Automated pytest tests

## Run

```bash
python -m venv .venv
# Windows:
.venv\Scripts\activate
# macOS/Linux:
source .venv/bin/activate

pip install -r requirements.txt
uvicorn app.main:app --reload
```

Open:
- API: http://127.0.0.1:8000
- API docs: http://127.0.0.1:8000/docs
- Web interface: http://127.0.0.1:8000/

Optional API key:
```bash
# Windows PowerShell
$env:MIND_TIMELINE_API_KEY="change-me"
uvicorn app.main:app --reload
```

If the API key is enabled, send:
`X-API-Key: change-me`

## Privacy
The default database is local SQLite. Do not put real personal experiences into a public Git repository.
For a real deployment, use HTTPS, a proper secret manager, encrypted storage/backups, authentication, access controls, and professional privacy/security review.
