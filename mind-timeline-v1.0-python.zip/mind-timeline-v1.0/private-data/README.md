# PRIVATE DATA

Do not commit real personal experiences to a public repository.

Keep private exports, backups and identifying information outside the public Git repository.
