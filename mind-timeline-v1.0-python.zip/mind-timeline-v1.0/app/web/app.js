const $=id=>document.getElementById(id);

async function api(url, options={}) {
  const r=await fetch(url, options);
  if(!r.ok) throw new Error((await r.json().catch(()=>({}))).detail || r.statusText);
  return r.json();
}

async function loadEvents(){
  const q=encodeURIComponent($("search").value);
  const c=encodeURIComponent($("filter").value);
  const data=await api(`/api/events?q=${q}&category=${c}`);
  const box=$("timeline");
  box.innerHTML="";
  data.forEach(e=>{
    const div=document.createElement("article");
    div.className="event";
    div.innerHTML=`
      <h3>${esc(e.title)}</h3>
      <div class="meta">${esc(e.occurred_at)} · ${esc(e.category)} · significance ${e.significance}/10 · confidence ${e.confidence}</div>
      <p><b>Observation:</b> ${esc(e.observation)}</p>
      <p><b>Interpretation:</b> ${esc(e.interpretation)}</p>
      <p><b>Context:</b> ${esc(e.context)}</p>
      <div class="meta">Evidence: ${esc(e.evidence_status)} · Tags: ${esc(e.tags.join(", "))}</div>
      <div class="actions"><button class="danger" onclick="removeEvent('${e.id}')">Delete</button></div>`;
    box.appendChild(div);
  });
}
function esc(s){return String(s??"").replace(/[&<>"']/g,m=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#039;"}[m]))}
async function removeEvent(id){
  if(!confirm("Delete this event?")) return;
  await api("/api/events/"+id,{method:"DELETE"});
  loadEvents();
}
$("eventForm").addEventListener("submit",async ev=>{
  ev.preventDefault();
  const dt=$("occurred_at").value;
  await api("/api/events",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({
    occurred_at:new Date(dt).toISOString(), title:$("title").value, category:$("category").value,
    observation:$("observation").value, interpretation:$("interpretation").value, context:$("context").value,
    significance:Number($("significance").value), confidence:Number($("confidence").value),
    evidence_status:$("evidence_status").value,
    tags:$("tags").value.split(",").map(x=>x.trim()).filter(Boolean)
  })});
  ev.target.reset(); $("significance").value=0; $("confidence").value=.5; loadEvents();
});
$("search").addEventListener("input",loadEvents);
$("filter").addEventListener("change",loadEvents);
async function downloadJSON(){
  const d=await api("/api/exports/json");
  const a=document.createElement("a");
  a.href=URL.createObjectURL(new Blob([JSON.stringify(d,null,2)],{type:"application/json"}));
  a.download="mind-timeline-export.json"; a.click();
}
loadEvents();
