import json
from fastapi import APIRouter
from fastapi.responses import JSONResponse, PlainTextResponse
from .database import connect
from .utils import row_event, row_relationship

router = APIRouter()

@router.get("/json")
def export_json():
    conn = connect()
    events = [row_event(r) for r in conn.execute("SELECT * FROM events ORDER BY occurred_at").fetchall()]
    relationships = [row_relationship(r) for r in conn.execute("SELECT * FROM relationships ORDER BY created_at").fetchall()]
    conn.close()
    return JSONResponse({"schema_version":"1.0","events":events,"relationships":relationships})

@router.get("/anonymous")
def anonymous_export():
    conn = connect()
    events = conn.execute("""SELECT id,occurred_at,category,significance,confidence,
                             evidence_status,parent_id FROM events ORDER BY occurred_at""").fetchall()
    rels = conn.execute("""SELECT source_id,target_id,relationship_type FROM relationships""").fetchall()
    conn.close()
    # Deliberately excludes title, free text, tags and notes.
    return JSONResponse({
        "schema_version":"1.0-anonymous",
        "events":[dict(r) for r in events],
        "relationships":[dict(r) for r in rels]
    })

@router.get("/clinician-summary", response_class=PlainTextResponse)
def clinician_summary():
    conn = connect()
    events = [row_event(r) for r in conn.execute("SELECT * FROM events ORDER BY occurred_at").fetchall()]
    rels = [row_relationship(r) for r in conn.execute("SELECT * FROM relationships ORDER BY created_at").fetchall()]
    conn.close()
    lines = [
        "MIND TIMELINE — NEUTRAL SUMMARY",
        "This document records reported experiences and their context.",
        "It is not a diagnosis.",
        "",
    ]
    for i, e in enumerate(events, 1):
        lines += [
            f"{i}. {e['occurred_at']} — {e['title']}",
            f"   Category: {e['category']}",
            f"   Observation: {e['observation']}",
            f"   Interpretation: {e['interpretation']}",
            f"   Context: {e['context']}",
            f"   Significance: {e['significance']}/10",
            f"   Confidence: {e['confidence']:.2f}",
            f"   Evidence status: {e['evidence_status']}",
            ""
        ]
    if rels:
        lines.append("Relationships:")
        for r in rels:
            lines.append(f"- {r['source_id']} --[{r['relationship_type']}]--> {r['target_id']}")
    return "\n".join(lines)

@router.get("/history")
def history():
    conn = connect()
    rows = conn.execute("SELECT * FROM history ORDER BY id DESC").fetchall()
    conn.close()
    return [dict(r) for r in rows]
