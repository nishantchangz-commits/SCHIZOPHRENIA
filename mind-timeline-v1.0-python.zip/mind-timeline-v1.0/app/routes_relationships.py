import uuid
from fastapi import APIRouter, HTTPException
from .database import connect
from .schemas import RelationshipCreate
from .utils import now_iso, row_relationship

router = APIRouter()

@router.post("", status_code=201)
def create_relationship(payload: RelationshipCreate):
    if payload.source_id == payload.target_id:
        raise HTTPException(400, "An event cannot relate to itself")
    conn = connect()
    for eid in (payload.source_id, payload.target_id):
        if not conn.execute("SELECT id FROM events WHERE id=?", (eid,)).fetchone():
            conn.close()
            raise HTTPException(404, f"Event not found: {eid}")
    rid = str(uuid.uuid4())
    conn.execute("""INSERT INTO relationships
    (id,source_id,target_id,relationship_type,note,created_at)
    VALUES(?,?,?,?,?,?)""",
    (rid,payload.source_id,payload.target_id,payload.relationship_type,payload.note,now_iso()))
    conn.commit()
    row = conn.execute("SELECT * FROM relationships WHERE id=?", (rid,)).fetchone()
    conn.close()
    return row_relationship(row)

@router.get("")
def list_relationships():
    conn = connect()
    rows = conn.execute("SELECT * FROM relationships ORDER BY created_at").fetchall()
    conn.close()
    return [row_relationship(r) for r in rows]

@router.delete("/{relationship_id}")
def delete_relationship(relationship_id: str):
    conn = connect()
    cur = conn.execute("DELETE FROM relationships WHERE id=?", (relationship_id,))
    conn.commit()
    conn.close()
    if cur.rowcount == 0:
        raise HTTPException(404, "Relationship not found")
    return {"deleted": relationship_id}
