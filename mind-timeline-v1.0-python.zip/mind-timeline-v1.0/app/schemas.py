from datetime import datetime
from typing import Literal
from pydantic import BaseModel, Field, field_validator

Category = Literal["observation", "interpretation", "imagination", "dream", "memory", "perception", "other"]
EvidenceStatus = Literal["unknown", "reported", "supported", "unverified", "contradicted"]

class EventCreate(BaseModel):
    occurred_at: datetime
    title: str = Field(min_length=1, max_length=200)
    category: Category
    observation: str = Field(default="", max_length=10000)
    interpretation: str = Field(default="", max_length=10000)
    context: str = Field(default="", max_length=10000)
    significance: int = Field(default=0, ge=0, le=10)
    confidence: float = Field(default=0.5, ge=0, le=1)
    evidence_status: EvidenceStatus = "unknown"
    tags: list[str] = Field(default_factory=list, max_length=30)
    parent_id: str | None = None

    @field_validator("tags")
    @classmethod
    def clean_tags(cls, value):
        return [str(x).strip()[:50] for x in value if str(x).strip()][:30]

class EventUpdate(EventCreate):
    pass

class RelationshipCreate(BaseModel):
    source_id: str
    target_id: str
    relationship_type: str = Field(min_length=1, max_length=80)
    note: str = Field(default="", max_length=5000)

class ImportPayload(BaseModel):
    events: list[EventCreate] = Field(default_factory=list)
    relationships: list[RelationshipCreate] = Field(default_factory=list)
