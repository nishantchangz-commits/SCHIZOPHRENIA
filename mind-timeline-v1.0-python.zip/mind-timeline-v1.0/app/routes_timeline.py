from fastapi import APIRouter, HTTPException
from .database import connect
from .schemas import ImportPayload
from .utils import now_iso, dumps, row_event, row_relationship
import uuid

router = APIRouter()

@router.get("")
def timeline():
    conn = connect()
    events = [row_event(r) for r in conn.execute("SELECT * FROM events ORDER BY occurred_at").fetchall()]
    rels = [row_relationship(r) for r in conn.execute("SELECT * FROM relationships").fetchall()]
    conn.close()
    children = {}
    for e in events:
        children.setdefault(e["parent_id"], []).append(e["id"])
    return {"events":events, "relationships":rels, "children":children}

@router.post("/import")
def import_data(payload: ImportPayload):
    conn = connect()
    inserted = 0
    try:
        ids = set()
        for e in payload.events:
            eid = str(uuid.uuid4())
            ids.add(eid)
            conn.execute("""INSERT INTO events
            (id,occurred_at,title,category,observation,interpretation,context,
             significance,confidence,evidence_status,tags,parent_id,created_at,updated_at)
             VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (eid,e.occurred_at.isoformat(),e.title,e.category,e.observation,e.interpretation,
             e.context,e.significance,e.confidence,e.evidence_status,dumps(e.tags),
             None,now_iso(),now_iso()))
            inserted += 1
        conn.commit()
    finally:
        conn.close()
    return {"imported_events": inserted, "imported_relationships": 0,
            "note":"Imported events receive new IDs; relationships are not imported unless their IDs are mapped explicitly."}
