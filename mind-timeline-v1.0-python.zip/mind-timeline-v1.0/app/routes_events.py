import uuid
from fastapi import APIRouter, HTTPException, Query
from .database import connect
from .schemas import EventCreate, EventUpdate
from .utils import now_iso, dumps, row_event

router = APIRouter()

def get_event(event_id):
    conn = connect()
    row = conn.execute("SELECT * FROM events WHERE id=?", (event_id,)).fetchone()
    conn.close()
    return row

@router.post("", status_code=201)
def create_event(payload: EventCreate):
    event_id = str(uuid.uuid4())
    now = now_iso()
    conn = connect()
    if payload.parent_id and not conn.execute("SELECT id FROM events WHERE id=?", (payload.parent_id,)).fetchone():
        conn.close()
        raise HTTPException(400, "parent_id does not exist")
    conn.execute("""INSERT INTO events
    (id, occurred_at, title, category, observation, interpretation, context,
     significance, confidence, evidence_status, tags, parent_id, created_at, updated_at)
    VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
    (event_id, payload.occurred_at.isoformat(), payload.title, payload.category,
     payload.observation, payload.interpretation, payload.context,
     payload.significance, payload.confidence, payload.evidence_status,
     dumps(payload.tags), payload.parent_id, now, now))
    conn.execute("INSERT INTO history(action,entity_type,entity_id,snapshot,created_at) VALUES(?,?,?,?,?)",
                 ("create","event",event_id,dumps(payload.model_dump(mode="json")),now))
    conn.commit()
    row = conn.execute("SELECT * FROM events WHERE id=?", (event_id,)).fetchone()
    conn.close()
    return row_event(row)

@router.get("")
def list_events(q: str | None = Query(None), category: str | None = None):
    conn = connect()
    sql = "SELECT * FROM events WHERE 1=1"
    params = []
    if category:
        sql += " AND category=?"
        params.append(category)
    if q:
        sql += " AND (title LIKE ? OR observation LIKE ? OR interpretation LIKE ? OR context LIKE ?)"
        like = f"%{q}%"
        params += [like, like, like, like]
    sql += " ORDER BY occurred_at ASC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [row_event(r) for r in rows]

@router.get("/{event_id}")
def get_one(event_id: str):
    row = get_event(event_id)
    if not row:
        raise HTTPException(404, "Event not found")
    return row_event(row)

@router.put("/{event_id}")
def update_event(event_id: str, payload: EventUpdate):
    if not get_event(event_id):
        raise HTTPException(404, "Event not found")
    conn = connect()
    if payload.parent_id and not conn.execute("SELECT id FROM events WHERE id=?", (payload.parent_id,)).fetchone():
        conn.close()
        raise HTTPException(400, "parent_id does not exist")
    old = dict(conn.execute("SELECT * FROM events WHERE id=?", (event_id,)).fetchone())
    now = now_iso()
    conn.execute("""UPDATE events SET occurred_at=?, title=?, category=?, observation=?,
    interpretation=?, context=?, significance=?, confidence=?, evidence_status=?,
    tags=?, parent_id=?, updated_at=? WHERE id=?""",
    (payload.occurred_at.isoformat(), payload.title, payload.category, payload.observation,
     payload.interpretation, payload.context, payload.significance, payload.confidence,
     payload.evidence_status, dumps(payload.tags), payload.parent_id, now, event_id))
    conn.execute("INSERT INTO history(action,entity_type,entity_id,snapshot,created_at) VALUES(?,?,?,?,?)",
                 ("update","event",event_id,dumps(old),now))
    conn.commit()
    row = conn.execute("SELECT * FROM events WHERE id=?", (event_id,)).fetchone()
    conn.close()
    return row_event(row)

@router.delete("/{event_id}")
def delete_event(event_id: str):
    if not get_event(event_id):
        raise HTTPException(404, "Event not found")
    conn = connect()
    old = dict(conn.execute("SELECT * FROM events WHERE id=?", (event_id,)).fetchone())
    now = now_iso()
    conn.execute("INSERT INTO history(action,entity_type,entity_id,snapshot,created_at) VALUES(?,?,?,?,?)",
                 ("delete","event",event_id,dumps(old),now))
    conn.execute("DELETE FROM events WHERE id=?", (event_id,))
    conn.commit()
    conn.close()
    return {"deleted": event_id}
