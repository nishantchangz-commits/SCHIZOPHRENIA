import json
from datetime import datetime, timezone

def now_iso():
    return datetime.now(timezone.utc).isoformat()

def dumps(value):
    return json.dumps(value, ensure_ascii=False)

def loads(value, default):
    try:
        return json.loads(value)
    except Exception:
        return default

def row_event(row):
    d = dict(row)
    d["tags"] = loads(d.pop("tags", "[]"), [])
    return d

def row_relationship(row):
    return dict(row)
