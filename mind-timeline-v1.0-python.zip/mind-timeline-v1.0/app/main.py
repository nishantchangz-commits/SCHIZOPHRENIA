import os
from pathlib import Path
from fastapi import FastAPI, Depends, Header, HTTPException
from fastapi.responses import HTMLResponse, FileResponse
from fastapi.middleware.cors import CORSMiddleware

from .database import init_db
from .routes_events import router as events_router
from .routes_relationships import router as relationships_router
from .routes_exports import router as exports_router
from .routes_timeline import router as timeline_router

BASE_DIR = Path(__file__).resolve().parent
WEB_DIR = BASE_DIR / "web"

app = FastAPI(
    title="Mind Timeline API",
    version="1.0.0",
    description="Privacy-first experience journaling and communication tool. Not a diagnostic system."
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://127.0.0.1:8000", "http://localhost:8000"],
    allow_credentials=False,
    allow_methods=["GET", "POST", "PUT", "DELETE"],
    allow_headers=["Content-Type", "X-API-Key"],
)

API_KEY = os.getenv("MIND_TIMELINE_API_KEY")

@app.middleware("http")
async def security_headers(request, call_next):
    response = await call_next(request)
    response.headers["X-Content-Type-Options"] = "nosniff"
    response.headers["X-Frame-Options"] = "DENY"
    response.headers["Referrer-Policy"] = "no-referrer"
    return response

def require_api_key(x_api_key: str | None = Header(default=None)):
    if API_KEY and x_api_key != API_KEY:
        raise HTTPException(status_code=401, detail="Invalid or missing API key")
    return True

init_db()

app.include_router(events_router, prefix="/api/events", dependencies=[Depends(require_api_key)])
app.include_router(relationships_router, prefix="/api/relationships", dependencies=[Depends(require_api_key)])
app.include_router(exports_router, prefix="/api/exports", dependencies=[Depends(require_api_key)])
app.include_router(timeline_router, prefix="/api/timeline", dependencies=[Depends(require_api_key)])

@app.get("/api/health")
def health():
    return {"status": "ok", "version": "1.0.0", "diagnostic": False}

@app.get("/", response_class=HTMLResponse)
def home():
    return FileResponse(WEB_DIR / "index.html")

@app.get("/app.js")
def javascript():
    return FileResponse(WEB_DIR / "app.js", media_type="application/javascript")

@app.get("/style.css")
def stylesheet():
    return FileResponse(WEB_DIR / "style.css", media_type="text/css")
