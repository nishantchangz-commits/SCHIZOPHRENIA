import os
os.environ.pop("MIND_TIMELINE_API_KEY", None)

from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)

def test_health():
    r=client.get("/api/health")
    assert r.status_code==200
    assert r.json()["version"]=="1.0.0"

def test_create_and_list_event():
    payload={
        "occurred_at":"2026-01-01T10:00:00Z",
        "title":"Test experience",
        "category":"observation",
        "observation":"A test observation",
        "interpretation":"A personal interpretation",
        "context":"Test context",
        "significance":5,
        "confidence":0.8,
        "evidence_status":"reported",
        "tags":["test"]
    }
    r=client.post("/api/events",json=payload)
    assert r.status_code==201
    event=r.json()
    assert event["title"]=="Test experience"

    r=client.get("/api/events?q=Test")
    assert r.status_code==200
    assert any(x["id"]==event["id"] for x in r.json())

    client.delete("/api/events/"+event["id"])
